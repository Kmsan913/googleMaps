# Plan Of Action

- Create Wireframe done

- setup Base HTML Structure done

- import google maps to window (HTML file) DONE

- Add Text store locator DONE

- add input box DONE

- add store list container DONE

- Add individual store container DONE

DAY 2

- style indv store item in the store list DONE

- show all store in store list based on rwd  DONE

- show markers for stores based on rwd DONE

- show info window when clicked on store

- Maybe beautiful transition 




-complete styling for marker info window DONE

-open infor marker on selection in stores list  DONE

-allow user to search for stores with a zip  DONE

-add a beautiful transition on hover of a store  DONE

**FIN**
